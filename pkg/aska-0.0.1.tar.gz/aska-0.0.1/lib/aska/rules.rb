module Aska
  class Rules
    
  end
end